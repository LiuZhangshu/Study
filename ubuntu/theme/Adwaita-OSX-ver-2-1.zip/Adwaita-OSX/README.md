# Adwaita-OSX
Adwaita with OSX window controls with full support for dark Adwaita theme

For people who just want the default experience enhanced just a bit

Based on USBA's Adwaita-OSX repository that sadly, hasn't been updated in over 8 months, and since it is under GPL, I figured I'd take over.
The difference with my repo is that I also made dark version and install scripts.

Currently I can guarantee this theme to work on GNOME. The only other I know not to work is XFCE but I can't really seem to fix it.

## Instalation
The install script will install the themes to either /usr/share/themes or home/.themes, depending on whether it was run as superuser. This way you can choose which you like better.

# Preview

## Dark
![alt text](https://i.imgur.com/BnyxYjX.jpg "Preview-dark")

## Light
![alt text](https://i.imgur.com/fruih5y.jpg "Preview-light")


Suggested icon theme that suits well - ([La Captaine](https://github.com/keeferrourke/la-capitaine-icon-theme))
