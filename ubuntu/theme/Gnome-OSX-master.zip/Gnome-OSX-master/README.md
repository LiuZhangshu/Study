# Gnome-OSX

A gnome-specific GTK theme that mimics the UI-style of OSX

![](https://raw.githubusercontent.com/paullinuxthemer/Gnome-OSX/master/SC4.jpg)
