package FAST3D;

import java.sql.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

/**
 * Summary description for PubInfo.
 * 
 */

public class PubInfo {
	private PubInfo() {
		//
		// TODO: Add constructor logic here
		//
	}

	public static final int WriteBufferSize = 1024 * 1024 * 4; // 1M

	public static final int FlagDrop = -1;
	public static final int FlagBuilding = 1;
	public static final int FlagOutdoor = 0;
	public static final int FlagRoad = 2;
	public static final int FlagRoadBuilding = 3;

	public static final int HeightStep = 15; // 15 meters
	public static final int PenetrationLoss = 15; // 15 db

	public static final int BatchInsertCount = 99999;

	// public static String OutTable = "LOC_MSR";
	public static String InMRFolder = "", FileFilter = "*.csv", OutFolder = ".";

	public static String Hostname = "127.0.0.1";
	public static int Port = 1521;
	public static String Username = "fast";
	public static String Password = "";
	public static String SID = "fast";
	public static String City = ""; // default to blank to get city from
									// database table
	public static boolean ifBuildingMR = true;
	public static int XSplit = 3, YSplit = 3;
	public static String TimeFilter = "";
	public static int MaxBufferRecordCount = 2000000; // total 4M, to keep max  records in mem, including locating and writing
	public static int MaxBufferRecordCount2 = 2000000;
	public static String MaxThreads = "auto";
	public static String IndoorBuildingListFile = "", BuildingListFile = "", CellConfigFile = "", GridConfigFile = "";

	public static boolean IfKeepMR = true;
	public static long OutPutFileSize = 1L * 1024 * 1024 * 1024;

	// private static final String driverName =
	// "org.apache.hadoop.hive.jdbc.HiveDriver";
	private static final String driverName = "oracle.jdbc.OracleDriver";

	public static Connection GetConnection() throws Exception {
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
		// return DriverManager.getConnection("jdbc:hive:@" + Hostname + ":" +
		// Port + "/default", Username, Password);
		return DriverManager
				.getConnection(
						"jdbc:oracle:thin:@(DESCRIPTION = (ADDRESS = (PROTOCOL = TCP)(HOST = " + Hostname + ")(PORT = "
								+ Port + "))(CONNECT_DATA = (SERVER = DEDICATED) (SERVICE_NAME = " + SID + ")))",
						Username, Password);
	}

	static final String NewLine = "\n";

	public static String PrintOption() {
		return "City=" + City + NewLine + "IfKeepMR=" + IfKeepMR + NewLine + "IfBuildingMROnly=" + ifBuildingMR
				+ NewLine + "CellConfigFile=" + CellConfigFile + NewLine + "GridConfigFile=" + GridConfigFile + NewLine
				+ "IndoorBuildingList=" + IndoorBuildingListFile + NewLine + "BuildingList=" + BuildingListFile
				+ NewLine + "MaxLocatingRecords=" + MaxBufferRecordCount + NewLine + "MaxThreads=" + MaxThreads
				+ NewLine + "MaxWritingRecords=" + MaxBufferRecordCount2 + NewLine + "OutputFileSize="
				+ OutPutFileSize / 1024 / 1024 / 1024 + "G" + NewLine + "OutputFolder=" + OutFolder + NewLine + "Host="
				+ Hostname + NewLine + "Port=" + Port + NewLine + "User=" + Username + NewLine + "Password=" + Password
				+ NewLine + "SourceFolder=" + InMRFolder + NewLine + "FileFilter=" + FileFilter + NewLine + "SID=" + SID
				+ NewLine + "TimeFilter=" + TimeFilter + NewLine + "XSplit=" + XSplit + NewLine + "YSplit=" + YSplit
				+ NewLine;
	}

	public static String ToReadableStr(long num) {
		return num > 1024 * 1024 * 1024 ? String.format("%0.3f", num / 1024.0 / 1024 / 1024) + "G"
				: num > 1024 * 1024 ? String.format("%0.3f", num / 1024.0 / 1024) + "M"
						: num > 1024 ? String.format("%0.3f", num / 1024.0) + "K" : num + "B";
	}

	public static DecimalFormat Double6 = new DecimalFormat("#####0.000000");

	public static String ToReadableTime(java.util.Date etime, java.util.Date stime) {
		long ms = etime.getTime() - stime.getTime();
		String ss = "";
		long s = ms % 1000;
		ms = ms / 1000;
		ss = s + "ms";
		long m = ms % 60;
		ms = ms / 60;
		if (ms > 0 || m > 0) {
			ss = m + "s" + ss;
		}
		int h = (int) (ms % 60);
		ms = ms / 60;
		if (ms > 0 || h > 0) {
			ss = h + "m" + ss;
		}
		int d = (int) ms % 24;
		ms = ms / 24;
		if (ms > 0 || d > 0) {
			ss = d + "H" + ss;
			if (ms > 0)
				ss = ms + "D" + ss;
		}

		return ss;
	}

	public static final SimpleDateFormat DateYMD = new SimpleDateFormat("yyyyMMdd");
	public static final SimpleDateFormat DateYMDH = new SimpleDateFormat("yyyyMMddHH");

	// earfcn to freq
	public static int GetFreq(int earfcn) {
		if (earfcn < 0)
			return -1;
		if (earfcn < 36200) { // band 33
			return 1900 + (int) (0.1 * (earfcn - 36000));
		}
		if (earfcn < 36350) { // band 34
			return 2010 + (int) (0.1 * (earfcn - 36200));
		}
		if (earfcn < 36950) { // band 35
			return 1850 + (int) (0.1 * (earfcn - 36350));
		}
		if (earfcn < 37550) { // band 36
			return 1930 + (int) (0.1 * (earfcn - 36950));
		}
		if (earfcn < 37750) { // band 37
			return 1910 + (int) (0.1 * (earfcn - 37550));
		}
		if (earfcn < 38250) { // band 38
			return 2570 + (int) (0.1 * (earfcn - 37750));
		}
		if (earfcn < 38650) { // band 39
			return 1880 + (int) (0.1 * (earfcn - 38250));
		}
		if (earfcn < 39650) { // band 40
			return 2300 + (int) (0.1 * (earfcn - 38650));
		}
		if (earfcn < 41590) { // band 41
			return 2496 + (int) (0.1 * (earfcn - 39650));
		}
		if (earfcn < 43590) { // band 42
			return 3400 + (int) (0.1 * (earfcn - 41590));
		}
		if (earfcn < 45590) { // band 43
			return 3600 + (int) (0.1 * (earfcn - 43590));
		}
		// band 44
		return 703 + (int) (0.1 * (earfcn - 45590));
	}
}