﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace ORA2CSV
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private delegate void UpdateProgress(int o, object v);
        private UpdateProgress myDelegate;
        private DateTime sTime;
        private delegate void MyAddText(string text);
        private MyAddText mylog;
        private System.Windows.Forms.Timer timer1;
        private long maxFileLength;
        List<SQLTask> tskLst = new List<SQLTask>();

        public MainWindow()
        {
            InitializeComponent();
            myDelegate = new UpdateProgress(UpdatePro);
            mylog = new MyAddText(LogLine);
            timer1 = new System.Windows.Forms.Timer();
            timer1.Interval = 500;
            timer1.Tick += timer1_Tick;
            maxFileLength = Properties.Settings.Default.MaxFileSize > 0 ? 1024L * Properties.Settings.Default.MaxFileSize * 1024 * 1024 : long.MaxValue;
        }

        void timer1_Tick(object sender, EventArgs e)
        {
            Callback(PubInfo.CallBackUpdateCount, totalCount);
        }

        #region events

        private void Button_Start_Click(object sender, RoutedEventArgs e)
        {
            if (Button_Start.Content.ToString() == "Start")
            {
                Textbox_Log.Text = "";
                if (!CheckInput()) return;
                //Logger logger = new Logger(richTextBox1);
                try
                {
                    sTime = DateTime.Now;
                    Button_Start.Content = "Stop";
                    timer1.Start();
                    Groupbox_Settings.IsEnabled = false;
                    isRunning = true;
                    Log("Start at: " + sTime);
                    new Thread(new ThreadStart(Generate)).Start();
                    Textbox_Log.Focus();
                }
                catch (Exception ex)
                {
                    Log(ex);
                    Button_Start.Content = "Start";
                    Groupbox_Settings.IsEnabled = true;
                    isRunning = false;
                }
            }
            else
            {
                if ((System.Windows.Forms.MessageBox.Show("Are you sure to stop ?", "Warning", System.Windows.Forms.MessageBoxButtons.YesNo) ==
                    System.Windows.Forms.DialogResult.Yes)) Stop();
            }
        }

        #endregion

        private bool CheckInput()
        {
            if (TextBox_IP.Text == "")
            {
                Textbox_Log.AppendText("Please input host name.\n");
                return false;
            }
            int port = 0;
            try
            {
                port = Convert.ToInt32(TextBox_Port.Text);
            }
            catch
            {
                Textbox_Log.AppendText("Please input port.\n");
                return false;
            }
            if (TextBox_SID.Text == "")
            {
                Textbox_Log.AppendText("Please input SID.\n");
                return false;
            }
            if (TextBox_User.Text == "")
            {
                Textbox_Log.AppendText("Please input user name.\n");
                return false;
            }
            //if (txt_out.Text == "")
            //{
            //    Textbox_Log.AppendText("Please input out file name.\n");
            //    return false;
            //}
            //if (txt_Sql.Text == "")
            //{
            //    Textbox_Log.AppendText("Please input SQL to be executed.\n");
            //    return false;
            //}
            if (lstTasks.Items.Count == 0)
            {
                Textbox_Log.AppendText("No task found. Please add task to be executed.\n");
                return false;
            }
            PubInfo.Hostname = TextBox_IP.Text;
            PubInfo.Port = port;
            PubInfo.SID = TextBox_SID.Text;
            PubInfo.Username = TextBox_User.Text;
            PubInfo.Password = TextBox_Password.Password;
            return true;
        }

        public void Log(object msg)
        {
            string lin = DateTime.Now.ToString("[yyyy-MM-dd HH:mm:ss] ") + msg;
            Textbox_Log.Dispatcher.Invoke(mylog, lin);
        }

        private void LogLine(string msg)
        {
            if (Textbox_Log.LineCount > 10000)
            {//clear msg if too much
                Textbox_Log.Text = "";
            }
            Textbox_Log.AppendText(msg + "\n");
        }

        public void UpdatePro(int o, object v)
        {
            switch (o)
            {
                case PubInfo.CallBackFinish:
                    Button_Start.Content = "Start";
                    Groupbox_Settings.IsEnabled = true;
                    timer1.Stop();
                    break;
                case PubInfo.CallBackUpdateCount:
                    txt_status.Text = v.ToString();
                    break;
            }
        }

        private void Callback(int option, object result)
        {
            switch (option)
            {
                case PubInfo.CallBackFinish:
                    Groupbox_Settings.Dispatcher.Invoke(myDelegate, new object[] { option, result });
                    Log("Time used: " + (DateTime.Now - sTime));
                    break;
                case PubInfo.CallBackUpdateCount:
                    txt_status.Dispatcher.Invoke(myDelegate, new object[] { option, result });
                    break;
            }
        }

        private void btn_out_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "CSV file(*.csv)|*.csv";
            saveFileDialog1.FilterIndex = 1;
            saveFileDialog1.RestoreDirectory = true;
            saveFileDialog1.Title = "Select Filter File";
            if (File.Exists(txt_out.Text))
            {
                saveFileDialog1.InitialDirectory = System.IO.Path.GetDirectoryName(txt_out.Text);
                saveFileDialog1.FileName = txt_out.Text;
            }
            if (saveFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txt_out.Text = saveFileDialog1.FileName;
            }
        }

        bool isRunning;
        int totalCount = 0;
        private void Generate()
        {
            OracleConnection conn = null;
            //DateTime stime = DateTime.Now;
            try
            {
                Log("Connecting to database....");
                conn = new OracleConnection(PubInfo.GetConnString());
                conn.Open();
                foreach (SQLTask t in tskLst)
                    ExeTask(t, conn);
            }
            catch (Exception ex)
            {
                Log(ex);
            }
            finally
            {
                if (conn != null) conn.Close();
                Callback(PubInfo.CallBackUpdateCount, totalCount);
                Callback(PubInfo.CallBackFinish, -1);
            }
            //Log("Time used: " + (DateTime.Now - stime));
        }

        private void ExeTask(SQLTask tsk, OracleConnection conn)
        {
            StreamWriter writer = null;
            int p = 0;
            int k = 0;
            totalCount = 0;
            try
            {
                OracleCommand cmd = new OracleCommand(tsk.SQLStr, conn);
                Log("Executing: " + tsk.SQLStr);
                string dir = Path.GetDirectoryName(tsk.OutFile);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                using (OracleDataReader rd = cmd.ExecuteReader())
                {
                    while (rd.Read() && isRunning)
                    {
                        if (writer == null)
                        {
                            writer = new StreamWriter(new FileStream(Path.Combine(Path.GetDirectoryName(tsk.OutFile),
                                Path.GetFileNameWithoutExtension(tsk.OutFile) + "_" + p.ToString("000") + Path.GetExtension(tsk.OutFile)),
                                FileMode.Create, FileAccess.Write, FileShare.None, PubInfo.WriteBufferSize));
                            writer.Write(rd.GetName(0));
                            for (int i = 1; i < rd.FieldCount; i++)
                            {
                                writer.Write("," + rd.GetName(i));
                            }
                            writer.WriteLine();
                            p++;
                        }
                        totalCount++;
                        writer.Write(rd.GetOracleValue(0));
                        for (int i = 1; i < rd.FieldCount; i++)
                        {
                            writer.Write("," + rd.GetOracleValue(i));
                        }
                        writer.WriteLine();
                        k++;
                        if (k < 100) continue;
                        k = 0;
                        if (writer.BaseStream.Length > maxFileLength)
                        {
                            writer.Close();
                            writer = null;
                        }
                    }
                }
                Log(totalCount + " records are written to file: " + tsk.OutFile);
            }
            catch (Exception ex)
            {
                Log(ex);
            }
            finally
            {
                if (writer != null) writer.Close();
            }
        }

        private void Stop()
        {
            isRunning = false;

        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            if (txt_out.Text.Length > 0 && txt_Sql.Text.Length > 0)
            {
                SQLTask tsk = new SQLTask()
                {
                    SQLStr = txt_Sql.Text,
                    OutFile = txt_out.Text
                };
                if (tskLst.Contains(tsk))
                {
                    return;
                }
                tsk.Update();
                tskLst.Add(tsk);
                lstTasks.Items.Add(tsk.ItemStr);
            }
        }

        private void btn_remove_Click(object sender, RoutedEventArgs e)
        {
            if (lstTasks.SelectedIndex >= 0)
            {
                int sid = lstTasks.SelectedIndex;
                lstTasks.Items.RemoveAt(sid);
                tskLst.RemoveAt(sid);
            }
        }

        private void lstTasks_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstTasks.SelectedIndex < 0) return;
            SQLTask t = tskLst[lstTasks.SelectedIndex];
            txt_out.Text = t.OutFile;
            txt_Sql.Text = t.SQLStr;
        }
    }

    class SQLTask
    {
        public string SQLStr = "", OutFile = "";
        public string ItemStr = "";
        public void Update()
        {
            string fn = Path.GetFileName(OutFile);
            ItemStr = (SQLStr.Length > 60 ? SQLStr.Substring(0, 57) + "..." : SQLStr) + " => " +
                (OutFile.Length > 50 ? OutFile.Substring(0, 50 - 3 - fn.Length) + "..." + fn : OutFile);
        }

        public override bool Equals(object obj)
        {
            SQLTask s = obj as SQLTask;
            if (s == null) return false;
            return SQLStr == s.SQLStr && OutFile == s.OutFile;
        }

        public override int GetHashCode()
        {
            return SQLStr.GetHashCode() ^ OutFile.GetHashCode();
        }
    }
}
