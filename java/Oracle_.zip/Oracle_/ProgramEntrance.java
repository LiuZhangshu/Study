﻿package FAST3D;

import java.io.*;
import java.nio.file.*;
import java.util.Date;

public class ProgramEntrance {
	private static final String BuildVersion = "build 2017-05-27";

	public static void main(String[] args) {
		try {
			if (args.length < 1) {
				Help();
				return;
			}
			if (!new File(args[0]).exists()) {
				System.out.println("Config file does not exist: " + args[0]);
				return;
			}
			LoadConfig(args[0]);
			Logger log = new Logger();
			Date stime = new java.util.Date();
			log.Log("FAST3DCMD " + BuildVersion);
			log.Log("Start at : " + stime);
			log.Log("Configuration is : \n" + PubInfo.PrintOption());
			Generator g = new Generator();
			g.Init(log);
			g.Generate();
			log.Log("Time used: " + PubInfo.ToReadableTime(new java.util.Date(), stime));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void Help() {
		System.out.println("FAST3DCMD " + BuildVersion + " by xinfeng.chen@nokia.com");
		System.out.println("Usage: FAST3DCMD <config file>");
		System.out.println("<config file>\tWhere configuration stores, which includes (can be one or all of them):");
		System.out.println("MUST OPTIONS: ");
		System.out.println("\tPassword = Oracle login password, Default is ''(no password).");
		System.out.println("\tCity = City Name, must specify, default is ''");
		System.out.println("OPTIONAL OPTIONS: ");
		System.out.println("\tOuputFolder = Where 3D result files store, default is '.', current directory");
		System.out.println("\tSourceFolder = Where MR files store, default is '', which will read MR from database");
		System.out.println("\tIfBuildingMROnly = If process MRs in building only, not all MRs, default is 'true'");
		System.out.println(
				"\tIfKeepTempMR = If keep temp MR files on disk, default is 'true'. Set to 'false' to save disk space.");
		System.out.println("\tFileFilter = MR file filter in source folder, default is '*.csv'");
		System.out.println("\tCellConfigFile = Cell config file path, default is ''(Get cell config from database)");
		System.out.println("\tGridConfigFile = Grid config file path, default is ''(Get grid config from database)");
		System.out.println("\tHost = Oracle Server IP, default is 'localhost'");
		System.out.println("\tPort = Oracle Server Port, default is 1521");
		System.out.println("\tSID = Oracle Server Instance, default is 'fast'");
		System.out.println("\tUser = Oracle login user name, default is 'fast'");
		// System.out.println("\tTable = 3D MR Table Name, default is
		// 'LOC_MSR'");
		System.out.println("\tXSplit = Split number in longitude/X, default is 3");
		System.out.println("\tYSplit = Split number in latitude/Y, default is 3");
		System.out.println(
				"\tTimeFilter = Time filter string like '20160102;2016030405', can be day and/or hour, default is '', no filter means all time");
		// System.out.println("\tDoFast3D = Action is FAST3D, default is
		// 'true'");
		// System.out.println("\tDo3DGL = Action is 3DGL output file, default is
		// 'false'");
		System.out.println(
				"\tIndoorBuildingList = Indoor building covering list file, default is '', which will not do special casting for indoor MR");
		System.out
				.println("\tBuildingList = Building ID list file, default is '', which will do 3D locating for all MR");
		System.out.println("ADVANCED OPTIONS (DO NOT MODIFY THESE UNLESS YOU KNOW EXACTLY WHAT IT MEANS): ");
		System.out.println(
				"\tMaxLocatingRecords = Record count waiting for locating count in memory, default is 2000000");
		System.out
				.println("\tMaxWritingRecords = Record count waiting for writing count in memory, default is 2000000");
		System.out.println(
				"\tMaxThreads = Thread count run simultaneously, default is 'auto', will ajust according to CPU count. This option must be actual num in Linux");
		System.out.println("\tOutputFileSize = How large a result file shall be. Default is 1(G).");
	}

	public static void LoadConfig(String configfile) throws Exception {
		for (String lin : Files.readAllLines(FileSystems.getDefault().getPath(configfile))) {
			int idx = lin.indexOf("=");
			if (idx <= 0) {
				continue;
			}
			String lineheader = lin.substring(0, idx).toLowerCase();
			// C# TO JAVA CONVERTER NOTE: The following 'switch' operated on a
			// string member and was converted to Java 'if-else' logic:
			// switch (lin.Substring(0, idx).ToLower())
			// ORIGINAL LINE: case "host":
			if (lineheader.equals("host")) {
				PubInfo.Hostname = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "port":
			else if (lineheader.equals("port")) {
				PubInfo.Port = Integer.parseInt(lin.substring(idx + 1));
			}
			// ORIGINAL LINE: case "ifimport2db":
			else if (lineheader.equals("cellconfigfile")) {
				PubInfo.CellConfigFile = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "city":
			else if (lineheader.equals("city")) {
				PubInfo.City = lin.substring(idx + 1).toUpperCase();
			}
			// ORIGINAL LINE: case "password":
			else if (lineheader.equals("password")) {
				PubInfo.Password = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "user":
			else if (lineheader.equals("user")) {
				PubInfo.Username = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "table":
			else if (lineheader.equals("sid")) {
				PubInfo.SID = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "xsplit":
			else if (lineheader.equals("xsplit")) {
				PubInfo.XSplit = Integer.parseInt(lin.substring(idx + 1));
			}
			// ORIGINAL LINE: case "ysplit":
			else if (lineheader.equals("ysplit")) {
				PubInfo.YSplit = Integer.parseInt(lin.substring(idx + 1));
			}
			// ORIGINAL LINE: case "timefilter":
			else if (lineheader.equals("timefilter")) {
				PubInfo.TimeFilter = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "ifrecreatetable":
			else if (lineheader.equals("gridconfigfile")) {
				PubInfo.GridConfigFile = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "ifbuildingmronly":
			else if (lineheader.equals("ifbuildingmronly")) {
				PubInfo.ifBuildingMR = lin.substring(idx + 1).toLowerCase().equals("true");
			}
			// ORIGINAL LINE: case "ifkeeptempmr":
			else if (lineheader.equals("ifkeeptempmr")) {
				PubInfo.IfKeepMR = lin.substring(idx + 1).toLowerCase().equals("true");
			}
			// ORIGINAL LINE: case "maxlocatingrecords":
			else if (lineheader.equals("maxlocatingrecords")) {
				PubInfo.MaxBufferRecordCount = Integer.parseInt(lin.substring(idx + 1));
			}
			// ORIGINAL LINE: case "maxwritingrecords":
			else if (lineheader.equals("maxwritingrecords")) {
				PubInfo.MaxBufferRecordCount2 = Integer.parseInt(lin.substring(idx + 1));
			}
			// ORIGINAL LINE: case "maxthreads":
			else if (lineheader.equals("maxthreads")) {
				PubInfo.MaxThreads = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "indoorbuildinglist":
			else if (lineheader.equals("indoorbuildinglist")) {
				PubInfo.IndoorBuildingListFile = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "buildinglist":
			else if (lineheader.equals("buildinglist")) {
				PubInfo.BuildingListFile = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "outputfilesize":
			else if (lineheader.equals("outputfilesize")) {
				PubInfo.OutPutFileSize = 1024L * 1024 * 1024 * Integer.parseInt(lin.substring(idx + 1));
			}
			// ORIGINAL LINE: case "sourcefolder":
			else if (lineheader.equals("sourcefolder")) {
				PubInfo.InMRFolder = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "filefilter":
			else if (lineheader.equals("filefilter")) {
				PubInfo.FileFilter = lin.substring(idx + 1);
			}
			// ORIGINAL LINE: case "outputfolder":
			else if (lineheader.equals("outputfolder")) {
				PubInfo.OutFolder = lin.substring(idx + 1);
			}
		}
	}
}